package org.example;

import java.sql.*;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class SimpleTrans {



    public static void main(String[] args) {
        SimpleTrans trans = new SimpleTrans();
    }

}